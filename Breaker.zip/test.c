#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(){
    
    int test[5] = {6,4,7,3,1};
	printf("%d", test[-1]);

    

}

/*
Quick notes:
    char* may not be the same as char[] - glData*
*/